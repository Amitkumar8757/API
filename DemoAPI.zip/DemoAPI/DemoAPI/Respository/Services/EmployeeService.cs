﻿using DemoAPI.Models;
using DemoAPI.Respository.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoAPI.Respository.Services
{
    public class EmployeeService:IEmployee
    {
        private readonly OurDbContext dbContext;
        public EmployeeService(OurDbContext
            _dbContext)
        {
            dbContext = _dbContext;
        }

        public Employee GetEmployeeById(int id)
        {
            var emp = dbContext.Employees.SingleOrDefault(e => e.Id == id);
            return emp;
        }

        public List<Employee> GetEmployees()
        {
            return dbContext.Employees.ToList();
        }

        public Employee PostEmpoyee(Employee employee)
        {
            dbContext.Employees.Add(employee);
            dbContext.SaveChanges();
            return employee;
        }
    }
}
