﻿using DemoAPI.Models;
using DemoAPI.Respository.Contract;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployee employeeService;

        public EmployeeController(IEmployee employee)
        {
            employeeService = employee;
        }
        [HttpGet]
        [Route("GetAllEmployees")]
        public IActionResult GetAllEmployees()
        {
            var results = employeeService.GetEmployees();
            if (results.Count > 0)
            {


                return Ok(results);
            }
            else
            {
                return NotFound("Employee not found !");
            }
            
        }
        [HttpGet]
        [Route("GetEmployeeById/{id}")]
        public IActionResult GetEmployeeById (int id)
        {
            var results = employeeService.GetEmployeeById(id);
            if (results!=null)
            {


                return Ok(results);
            }
            else
            {
                return NotFound("Employee not found !");
            }

        }

        [HttpPost]
        public IActionResult Post(Employee employee)
        {
            var result=employeeService.PostEmpoyee(employee);
            if (result != null)
            {
                return Ok(result);
            }
            else
            {
                return Ok();
            }
            
        }

    }
    
}

